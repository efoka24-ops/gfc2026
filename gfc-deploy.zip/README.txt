# Deploiement GFC 2026

## IMPORTANT: CAMOO CSHIELD

Si vous utilisez CAMOO avec le shell CSHIELD (restreint), suivez le guide:
C:\Projects\gfc\DEPLOIEMENT-CAMOO-CSHIELD.md

Sinon, suivez les etapes ci-dessous pour un serveur standard:

## Etapes (Serveur Standard avec SSH):

1. Uploadez tout ce dossier vers /home/trugro9159/public_html/gfc/ via cPanel File Manager

2. Methode A - Script Web (RECOMMANDE pour CSHIELD):
   - Accedez a: https://votre-domaine.com/gfc/setup-web.php
   - Mot de passe: GFC@setup2026!
   - Suivez les instructions a l'ecran
   - SUPPRIMEZ setup-web.php apres l'installation

3. Methode B - SSH Standard (si disponible):
   ssh trugro9159_gfc@ftp-12.camoo.net

3. Installez les dependances:
   cd /home/trugro9159/gfc
   composer install --no-dev --optimize-autoloader

4. Configurez Laravel:
   php artisan key:generate
   php artisan migrate --force  
   php artisan db:seed --force

5. Permissions:
   chmod -R 775 storage bootstrap/cache

## URLs:
- API: https://gfc.camoo.hosting/api
- Dashboard: https://gfc.camoo.hosting/dashboard

## Login:
- Email: admin@gfc.local
- Mot de passe: GFC@admin2026!
